import express, { json } from 'express';
const app = express();
app.use(json());

import filmesRoutes from './routes/filmesRoutes';
app.use('/filmes', filmesRoutes);

export default app;

