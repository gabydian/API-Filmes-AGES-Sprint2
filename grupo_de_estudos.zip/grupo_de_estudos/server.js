import app from '../app/app.js';
app.listen(3000, () => {
  console.log('API rodando em http://localhost:3000');
});