const filmes = require('../model/filmes');

exports.getAll = (req,res) => res.json(filmes);
exports.getById = (req, res) => {
    const filme = filmes.find(f => f.id == req.params.id);
    if (!filme) return res.sendStatus(404);
    res.json(filme);
};

exports.create = (req, res) => {
    const {titulo, diretor, ano} = req.body;
    const novoFilme = {
        id: Number,
        titulo,
        diretor,
        ano
    };
    filmes.push(novoFilme);
    res.status(201).json(novoFilme);
};

exports.update = (req, res) => {
    const index = filmes.findIndex(f => f.id == req.params.id);
    if (index === -1) return res.sendStatus(404);
    filmes[index] = { ...filmes[index], ...req.body };
    res.json(filmes[index]);
};

exports.delete = (req, res) => {
    const index = filmes.findIndex(f => f.id == req.params.id);
    if (index === -1) return res.sendStatus(404);
    filmes.splice(index, 1);
    res.sendStatus(204);
};